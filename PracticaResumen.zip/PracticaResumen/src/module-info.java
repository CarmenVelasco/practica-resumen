module PracticaResumen {
	exports com.carmen.me;
}